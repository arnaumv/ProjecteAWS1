import pymysql
host = "52.174.49.212"
user = "arnau"
password = "P@ssw0rd"
database = "AdventureGame"

conn=pymysql.connect(host=host,user=user, password=password,database=database)
cur = conn.cursor()