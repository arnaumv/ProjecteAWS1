import pymysql
import Tools.BBDDconn as C
# sql = "select * from USER";
# cur.execute(sql)
# aa = cur.fetchall()
# print("aa =\n",aa)

#Querys predefinidas:
query_mostrarUsuarios = "select * from USER"


def insertGame(sql_query):
    C.cur.execute(sql_query)
    C.conn.commit()

def checkUser(user):
    if len(user) < 6 or len(user) > 12:
        print("Length to username have to be longer than 5 and shorter than 11 ")
        return False
    if not user.isalnum():
        print("user has to be alphanumeric")
        return False
        # Si llegamos aqui sabemos que es alpha
    if user.isdigit():
        print("User have to have digits and letters")
        return False
    if user.isalpha():
        print("User have to have digits and letters")
        return False
    return True

def checkPassword(password):
    #password=""
    if len(password)> 12 or len(password)<8:
        print("password has to have between 8 and 12 characters")
        return False
    if password.upper() == password or password.lower() == password:
        print("password have to include some uppercase and some lowercase")
        return False
    if password.isalnum():
        print("password has to contain some especial character")
        return False
    if password.replace(" ","") != password:
        print("password cannot contain spaces")
        return False
    return True

#insert into USER values (2,"pablo","pablo",1);
def insertUserBBDD(user,password):
    sql = "insert into USER values (id_user,\""+user+"\",\""+password+"\")"
    print("sqlQuery = ",sql)
    C.cur.execute(sql)
    C.conn.commit()
    # if len(user) < 6 or len(user) > 12:
    #     print("Length to username have to be longer than 5 and shorter than 11 ")
    #     return False
    # if not user.isalnum():
    #     print("user has to be alphanumeric")
    #     return False
    #     # Si llegamos aqui sabemos que es alpha
    # if user.isdigit():
    #     print("User have to have digits and letters")
    #     return False
    # if user.isalpha():
    #     print("User have to have digits and letters")
    #     return False
    # return True




def printUsuarios():
    C.cur.execute(query_mostrarUsuarios)
    tuplaQuery = C.cur.fetchall()
    print(" C.cur.description = \n",C.cur.description)

    for elemento in tuplaQuery:
        #cada elemento vuelve a ser una tupla
        print(C.cur.description[1][0]," : ",elemento[1])
    #print(tuplaQuery)

def getUsersInDictionary():
    diccionario = {}
    # vamos a devolver un diccionario del tipo:
    #{id_usuario:{"descripcion en mysql":"valorMysql"}}
    # {1:{"username":"pepe","password":"pepe"},4:{"username":"Pablo123","password":"Mario"}}
    C.cur.execute(query_mostrarUsuarios)
    tuplaQuery = C.cur.fetchall()
    for elemento in tuplaQuery:
        # elemento = (1,"pepe","pepe",1)
        subdict = {}

        subdict[C.cur.description[1][0]]=elemento[1]
        subdict[C.cur.description[2][0]] = elemento[2]
        diccionario[elemento[0]] = subdict
    return diccionario


# def clave(user, password):
#     sql = "insert into USER values (id_user,\"" + user + "\",\"" + password + "\")"
#     print("sqlQuery = ", sql)
#     C.cur.execute(sql)
#     C.conn.commit()
#     while True:
#         long = len(user)  # Calcular la longitud del nomre de usuario
#         y = user.isalnum()  # Calcula que la cadena contenga valores alfanuméricos
#
#         if y == False:  # La cadena contiene valores no alfanuméricos
#             print("El nombre de usuario puede contener solo letras y números")
#
#         if long < 6:
#             print("Length of username have to be longer than 6")
#
#         if long > 12:
#             print("Length of username have to be shorter than 12")
#
#         if long > 5 and long < 13 and y == True:
#             return True  # Verdadero si el tamaño es mayor a 5 y menor a 13
#         break
#
#         validar = False  # que se vayan cumpliendo los requisitos uno a uno.
#         long = len(password)  # Calcula la longitud de la contraseña
#         espacio = False  # variable para identificar espacios
#         mayuscula = False  # variable para identificar letras mayúsculas
#         minuscula = False  # variable para contar identificar letras minúsculas
#         numeros = False  # variable para identificar números
#         y = password.isalnum()  # si es alfanumérica retona True
#         correcto = True  # verifica que hayan mayuscula, minuscula, numeros y no alfanuméricos
#
#         for carac in password:  # ciclo for que recorre caracter por caracter en la contraseña
#
#             if carac.isspace() == True:  # Saber si el caracter es un espacio
#                 espacio = True  # si encuentra un espacio se cambia el valor user
#
#             if carac.isupper() == True:  # saber si hay mayuscula
#                 mayuscula = True  # acumulador o contador de mayusculas
#
#             if carac.islower() == True:  # saber si hay minúsculas
#                 minuscula = True  # acumulador o contador de minúsculas
#
#             if carac.isdigit() == True:  # saber si hay números
#                 numeros = True  # acumulador o contador de numeros
#
#         if espacio == True:  # hay espacios en blanco
#             print("La contraseña no puede contener espacios")
#         else:
#             validar = True  # se cumple el primer requisito que no hayan espacios
#
#         if long < 8 and validar == True:
#             print("Mínimo 8 caracteres")
#             validar = False  # cambia a Flase si no se cumple el requisito móinimo de caracteres
#
#         if mayuscula == True and minuscula == True and numeros == True and y == False and validar == True:
#             validar = True  # Cumple el requisito de tener mayuscula, minuscula, numeros y no alfanuméricos
#         else:
#             correcto = False  # uno o mas requisitos de mayuscula, minuscula, numeros y no alfanuméricos no se cumple
#
#         if validar == True and correcto == False:
#             print(
#                 "La contraseña elegida no es segura: debe contener letras minúsculas, mayúsculas, números y al menos 1 carácter no alfanumérico")
#
#         if validar == True and correcto == True:
#             return True
#         break
