# def checkUser (user):
#
#     if len(user) < 6 or len(user) > 12:
#         print("Length to username have to be longer than 5 and shorter than 11 ")
#         return False
#     if not user.isalnum():
#         print("user has to be alphanumeric")
#         return False
#     # Si llegamos aqui sabemos que es alpha
#     if user.isdigit():
#         print("User have to have digits and letters")
#         return False
#     if user.isalpha():
#         print("User have to have digits and letters")
#         return False
#     return True
#
def checkPassword(password):
    #password=""
    if len(password)> 12 or len(password)<8:
        print("password has to have between 8 and 12 characters")
        return False
    if password.upper() == password or password.lower() == password:
        print("password have to include some uppercase and some lowercase")
        return False
    if password.isalnum():
        print("password has to contain some especial character")
        return False
    if password.replace(" ","") != password:
        print("password cannot contain spaces")
        return False
    return True

