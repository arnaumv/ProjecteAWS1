import Tools.FuncionesAuxiliares as FA
import Tools.funcionesAccesoBBDD as AD
#user = "Pablo123"

# user = input("Username: ")
# while not FA.checkUser(user):
#     user = input("Username: ")

#password = input("password:")
#FA.checkPassword()
# while not FA.checkPassword(password):
#     password = input("Password")
#
# def insertGame(sql_query):
#     cur.execute(sql_query)
# idGame = input("dime d game"
# data = input("dame la fecha")
# sql = "insert into GAME values ("+idGame +", \""+data+"\")"
# print(sql)
# AD.insertGame(sql)

user = input("Usuario : ")
password = input("Password: ")
#game = input("game")
AD.clave(user,password)


#print(AD.getUsersInDictionary())