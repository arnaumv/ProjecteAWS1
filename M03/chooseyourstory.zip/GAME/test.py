pass_correct = False
while not pass_correct:
    pass_correct = True
    if no tienemayusculas :
        pass_correct = False
    if no tiene numeros:
        pass_correct = False
    if long <10:
        pass_correct = Falses
