def insertUser(conexion, user, password):
    sql = 'INSERT INTO usuario VALUES (id, user, password);'

    cursor = conexion.cursor()
    cursor.execute(sql, user,password)
    id.commit()

def checkUser (user):

    user = input ("Username: ")
    if len(user) < 6 or len(user) > 12:
        print("Length to username have to be longer than 5 and shorter than 11 ")
        num = False
        for carac in user:
            if carac.isdigit() == True:
                if not num:
                    print("The username must contain at least one number")
                else:
                    print("Correct User")

