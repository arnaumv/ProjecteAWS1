def nickname(nombre_usuario):
    long = len(nombre_usuario)  # Calcular la longitud del nomre de usuario
    y = nombre_usuario.isalnum()  # Calcula que la cadena contenga valores alfanuméricos

    if y == False:  # La cadena contiene valores no alfanuméricos
        print("El nombre de usuario puede contener solo letras y números")

    if long < 6:
        print("Length of username have to be longer than 6")

    if long > 12:
        print("Length of username have to be shorter than 12")

    if long > 5 and long < 13 and y == True:
        return True  # Verdadero si el tamaño es mayor a 5 y menor a 13